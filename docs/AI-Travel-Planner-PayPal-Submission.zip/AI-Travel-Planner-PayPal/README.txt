AI Travel Planner (PayPal edition)
Founder: Shaik Irfan (shaikirfan24bcs0136@iiitkottayam.ac.in)
Tagline: Your whole trip, planned and booked in minutes.
Code: https://github.com/magicalnature621-coder/ai-travel-planner-paypal

Contents
- pitch-deck/   Pitch deck (PDF)
- demo/         2-minute captioned product demo (MP4). It was recorded with the
                demo checkout; in this edition the payment step uses PayPal.
- screenshots/  Product screenshots
- source-code/  Full source code (Next.js + TypeScript + PostgreSQL)
                README.md to run it, SETUP.md for API keys (PayPal: section 4)

PayPal developer platform (sandbox)
- PayPal JavaScript SDK Smart Payment Buttons on the checkout page
  (src/components/PaymentForm.tsx)
- Orders v2 REST API + OAuth client credentials on the server (src/lib/paypal.ts):
  create order -> buyer approves -> server captures and verifies status
  COMPLETED, booking id and amount before the booking is confirmed
  (src/app/api/trips/[id]/paypal-order, src/app/api/trips/[id]/confirm)

AI
- Personalised day-by-day itinerary generated from the actual booking via the
  Groq API (Llama 3.3 70B), JSON validated against a schema, with a fallback plan
  (src/lib/itinerary.ts)

What is real vs demo (MVP)
- Working: sign-up/login, full booking flow (travel only, stay only, or both),
  live Indian Railways trains with real seat availability and fares, PayPal
  sandbox checkout, itinerary, PDF e-tickets and stay vouchers, email and
  WhatsApp confirmations, My Trips wallet.
- Demo data for now: flights, buses, hotels and restaurants; payments run in the
  PayPal sandbox (no real money); no real tickets are issued.
